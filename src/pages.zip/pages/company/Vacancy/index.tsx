import { useEffect, useState } from 'react';
import { Pen, PlusIcon, Users2, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import axiosInstance from '@/lib/axios';
import { useToast } from '@/components/ui/use-toast';
import { BlinkingDots } from '@/components/shared/blinking-dots';
import { Input } from '@/components/ui/input';
import moment from 'moment';
import { DynamicPagination } from '@/components/shared/DynamicPagination';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Tooltip,
  TooltipTrigger,
  TooltipContent
} from '@/components/ui/tooltip';
import { useSelector } from 'react-redux';

export default function Vacancy() {
  const [vacancy, setVacancy] = useState<any[]>([]);
  const [initialLoading, setInitialLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(100);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();
  const user = useSelector((state: any) => state.auth?.user) || null;
  const {id} = useParams()
  const fetchData = async (page: number, limit: number, search = '') => {
    try {
      setInitialLoading(true);
      const response = await axiosInstance.get('/hr/vacancy', {
        params: {
          page,
          companyId:id,
          limit,
          ...(search ? { searchTerm: search } : {})
        }
      });
      setVacancy(response.data.data.result || []);
      setTotalPages(response.data.data.meta.totalPage || 1);
    } catch (error) {
      console.error('Error fetching Vacancy:', error);
      toast({
        title: 'Failed to fetch vacancies',
        className: 'bg-red-500 border-none text-white'
      });
    } finally {
      setInitialLoading(false);
    }
  };

  useEffect(() => {
    fetchData(currentPage, entriesPerPage);
  }, [currentPage, entriesPerPage]);

  const handleStatusChange = async (id: string, status: boolean) => {
    try {
      const updatedStatus = status ? 'active' : 'closed';
      await axiosInstance.patch(`/hr/vacancy/${id}`, { status: updatedStatus });
      toast({
        title: 'Record updated successfully',
        className: 'bg-theme border-none text-white'
      });
      fetchData(currentPage, entriesPerPage);
    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: 'Failed to update status',
        className: 'bg-red-500 border-none text-white'
      });
    }
  };

  const handleSearch = () => {
    setCurrentPage(1); // reset to first page on search
    fetchData(1, entriesPerPage, searchTerm);
  };

  const handleNewVacancyClick = () => navigate('create-vacancy');

  const handleEdit = (vacancyData: any) => {
    navigate(`edit-vacancy/${vacancyData._id}`);
  };

  return (
    <div className="space-y-4 rounded-md bg-white p-6 shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className='flex flex-row items-center gap-4'>
          <h2 className=" flex items-center gap-2 text-2xl font-bold text-gray-900">
            <Users2 className="h-6 w-6" />
            All Vacancies
          </h2>
          <div className="flex items-center space-x-4">
            <Input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by vacancy title"
              className="h-8 max-w-[400px]"
            />
            <Button
              onClick={handleSearch}
              size="sm"
              className="min-w-[100px] border-none bg-theme text-white hover:bg-theme/90"
            >
              Search
            </Button>
          </div>
        </div>
        <Button
          className="bg-theme text-white hover:bg-theme/90"
          size="sm"
          onClick={handleNewVacancyClick}
        >
          <Plus className="mr-2 h-4 w-4" />
          New Vacancy
        </Button>
      </div>

      {/* Table */}
      <div className="">
        {initialLoading ? (
          <div className="flex justify-center py-6">
            <BlinkingDots size="large" color="bg-theme" />
          </div>
        ) : vacancy.length === 0 ? (
          <div className="flex justify-center py-6 text-gray-500">
            No records found.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Employment Type</TableHead>
                <TableHead>Application Deadline</TableHead>
                <TableHead>Posted By</TableHead>
                {/* <TableHead>Status</TableHead> */}
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vacancy.map((vac) => (
                <TableRow key={vac._id}>
                  <TableCell
                    onClick={() => navigate(`view-applicants/${vac._id}`)}
                  >
                    {vac.title}
                  </TableCell>
                  <TableCell
                    onClick={() => navigate(`view-applicants/${vac._id}`)}
                  >
                    {vac.employmentType}
                  </TableCell>
                  <TableCell
                    onClick={() => navigate(`view-applicants/${vac._id}`)}
                  >
                    {moment(vac.applicationDeadline).format('MMMM Do YYYY')}
                  </TableCell>
                  <TableCell
                    onClick={() => navigate(`view-applicants/${vac._id}`)}
                  >
                    {vac?.postedBy?.name}
                  </TableCell>
                  {/* <TableCell>
                    <Switch
                      checked={vac.status === 'active'}
                      onCheckedChange={(checked) =>
                        handleStatusChange(vac._id, checked)
                      }
                      className="mx-auto"
                    />
                  </TableCell> */}
                  <TableCell className="flex flex-row items-center justify-end gap-2 text-right">
                    {/* Show Applicants */}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          className="border-none bg-theme text-white hover:bg-theme/90"
                          size="sm"
                          onClick={() => navigate(`view-applicants/${vac._id}`)}
                        >
                          Check Applicants
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Show Applicants</TooltipContent>
                    </Tooltip>

                    {/* Edit Vacancy */}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          className="border-none bg-theme text-white hover:bg-theme/90"
                          size="sm"
                          onClick={() => handleEdit(vac)}
                        >
                          Edit{' '}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Edit Vacancy</TooltipContent>
                    </Tooltip>

                    {/* Add Applicant */}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          className="border-none bg-theme px-2 text-white hover:bg-theme/90"
                          size="sm"
                          onClick={() =>
                            navigate(`add-applicant/${vac._id}`, {
                              state: { vacancyTitle: vac.title }
                            })
                          }
                        >
                          Add Applicant
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Add Applicant</TooltipContent>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}

        {vacancy.length > 40 && (
          <>
            <DynamicPagination
              pageSize={entriesPerPage}
              setPageSize={setEntriesPerPage}
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </>
        )}
      </div>
    </div>
  );
}
