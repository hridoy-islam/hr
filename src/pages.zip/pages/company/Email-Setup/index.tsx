import { useEffect, useState } from 'react';
import { Pen, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';

import { useToast } from '@/components/ui/use-toast';
import axiosInstance from '@/lib/axios';
import { BlinkingDots } from '@/components/shared/blinking-dots';

import { Input } from '@/components/ui/input';
import { DynamicPagination } from '@/components/shared/DynamicPagination';
import { EmailConfigDialog } from './Components/emailConfigDialog';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

export default function EmailSetup() {
  const [emailConfigs, setEmailConfigs] = useState<any>([]);
  const [initialLoading, setInitialLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEmailConfig, setEditingEmailConfig] = useState<any>();
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState('');
const user = useSelector((state: any) => state.auth.user);
const {id} = useParams()
  const fetchData = async (page, entriesPerPage, searchTerm = '') => {
    try {
      if (initialLoading) setInitialLoading(true);
      const response = await axiosInstance.get(`/hr/email-setup`, {
        params: {
          page,
          limit: entriesPerPage,
           companyId:id,
          ...(searchTerm ? { searchTerm } : {})
        }
      });
      setEmailConfigs(response.data.data.result);
      setTotalPages(response.data.data.meta.totalPage);
    } catch (error) {
      console.error('Error fetching email configurations:', error);
    } finally {
      setInitialLoading(false);
    }
  };

  const handleSubmit = async (data) => {
    try {
      let response;

      if (editingEmailConfig) {
        // Update email configuration
        response = await axiosInstance.patch(
          `/hr/email-setup/${editingEmailConfig?._id}`,
          data
        );
      } else {
        // Create new email configuration
        response = await axiosInstance.post(`/hr/email-setup`,  {
        ...data,
        companyId: id
      });
      }

      // Check if the API response indicates success
      if (response.data && response.data.success === true) {
        toast({
          title: 'Email configuration updated successfully',
          className: 'bg-theme border-none text-white'
        });
      } else if (response.data && response.data.success === false) {
        toast({
          title: 'Operation failed',
          className: 'bg-red-500 border-none text-white'
        });
      } else {
        toast({
          title: 'Unexpected response. Please try again.',
          className: 'bg-red-500 border-none text-white'
        });
      }

      // Refresh data
      fetchData(currentPage, entriesPerPage);
    } catch (error) {
      toast({
        title: 'An error occurred. Please try again.',
        className: 'bg-red-500 border-none text-white'
      });
    } finally {
      setEditingEmailConfig(undefined); // Reset editing state
    }
  };

  const handleEdit = (emailConfig) => {
    setEditingEmailConfig(emailConfig);
    setDialogOpen(true);
  };

  useEffect(() => {
    fetchData(currentPage, entriesPerPage);
  }, [currentPage, entriesPerPage]);

  const handleSearch = () => {
    fetchData(currentPage, entriesPerPage, searchTerm);
  };

  return (
    <div>
      <div className="space-y-4 rounded-md bg-white p-6 shadow-lg">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex flex-row items-center gap-4">
            <h1 className="text-2xl font-bold   text-gray-900">
              All Email Configurations
            </h1>
            <div className="flex items-center space-x-4">
              <Input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by Email"
                className="h-8 max-w-[400px]"
              />
              <Button
                onClick={handleSearch}
                size="sm"
                className="min-w-[100px] border-none bg-theme text-white hover:bg-theme/90"
              >
                Search
              </Button>
            </div>
          </div>
          <Button
            className="bg-theme text-white hover:bg-theme/90"
            size="sm"
            onClick={() => setDialogOpen(true)}
          >
            <Plus className="mr-2 h-4 w-4" />
            New Email Configuration
          </Button>
        </div>

        {/* Search */}

        {/* Table */}
        <div className="overflow-x-auto">
          {initialLoading ? (
            <div className="flex justify-center py-6">
              <BlinkingDots size="large" color="bg-theme" />
            </div>
          ) : emailConfigs.length === 0 ? (
            <div className="flex justify-center py-6 text-gray-500">
              No records found.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Host</TableHead>
                  <TableHead>Port</TableHead>
                  <TableHead>Encryption</TableHead>
                  <TableHead>Authentication</TableHead>
                  <TableHead className="w-32 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {emailConfigs.map((config) => (
                  <TableRow key={config._id}>
                    <TableCell>{config.email}</TableCell>
                    <TableCell>{config.host}</TableCell>
                    <TableCell>{config.port}</TableCell>
                    <TableCell>{config.encryption}</TableCell>
                    <TableCell>
                      {config.authentication ? 'True' : 'False'}
                    </TableCell>
                    <TableCell className="text-center">
                      <div className='flex flex-row items-center justify-end'>

                      <Button
                        variant="ghost"
                        size="icon"
                        className="bg-theme text-white hover:bg-theme/90"
                        onClick={() => handleEdit(config)}
                        >
                        <Pen className="h-4 w-4" />
                      </Button>
                        </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
        {emailConfigs.length > 50 && (
          <>
            <DynamicPagination
              pageSize={entriesPerPage}
              setPageSize={setEntriesPerPage}
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </>
        )}
      </div>

      {/* Dialog */}
      <EmailConfigDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditingEmailConfig(undefined);
        }}
        onSubmit={handleSubmit}
        initialData={editingEmailConfig}
      />
    </div>
  );
}
