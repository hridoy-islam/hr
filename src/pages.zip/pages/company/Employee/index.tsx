import { useEffect, useState } from 'react';
import { DollarSign, Eye, Users2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import axiosInstance from '@/lib/axios';
import { useToast } from '@/components/ui/use-toast';
import { BlinkingDots } from '@/components/shared/blinking-dots';
import { Input } from '@/components/ui/input';
import { DynamicPagination } from '@/components/shared/DynamicPagination';
import { useNavigate, useParams } from 'react-router-dom';
import Select from 'react-select';
import { Badge } from '@/components/ui/badge';
import { useSelector } from 'react-redux';

interface OptionType {
  value: string;
  label: string;
}

export default function Employee() {
  const [employees, setEmployees] = useState<any[]>([]);
  const [initialLoading, setInitialLoading] = useState(true);
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(100);
  const { id } = useParams();
  const [searchInput, setSearchInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const [departments, setDepartments] = useState<OptionType[]>([]);
  const [designations, setDesignations] = useState<OptionType[]>([]);
  const [trainings, setTrainings] = useState<OptionType[]>([]);

  const [selectedDepartment, setSelectedDepartment] =
    useState<OptionType | null>(null);
  const [selectedDesignation, setSelectedDesignation] =
    useState<OptionType | null>(null);
  const [selectedTraining, setSelectedTraining] = useState<OptionType | null>(
    null
  );
  const user = useSelector((state: any) => state.auth?.user) || null;

  const navigate = useNavigate();

  const fetchData = async () => {
    try {
      setInitialLoading(true);
      const params: any = {
        page: currentPage,
        limit: entriesPerPage,
        role: 'employee',
        company: id
      };

      if (searchTerm) params.searchTerm = searchTerm;
      if (selectedDepartment) params.departmentId = selectedDepartment.value;
      if (selectedDesignation) params.designationId = selectedDesignation.value;
      if (selectedTraining) params.trainingId = selectedTraining.value; // Backend must support array query

      const response = await axiosInstance.get('/users', { params });

      setEmployees(response.data.data.result || []);
      setTotalPages(response.data.data.meta?.totalPage || 1);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
      toast({
        title: 'Error',
        description:
          error.response?.data?.message || 'Failed to load employees.',
        variant: 'destructive'
      });
    } finally {
      setInitialLoading(false);
    }
  };

  // Fetch filter options
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const [deptRes, desigRes, trainingRes] = await Promise.all([
          axiosInstance.get(`/hr/department?companyId=${id}&limit=all`),
          axiosInstance.get(`/hr/designation?companyId=${id}&limit=all`),
          axiosInstance.get(`/hr/training?companyId=${id}&limit=all`)
        ]);

        setDepartments(
          deptRes.data.data.result.map((d: any) => ({
            value: d._id,
            label: d.departmentName
          }))
        );
        setDesignations(
          desigRes.data.data.result.map((d: any) => ({
            value: d._id,
            label: d.title
          }))
        );
        setTrainings(
          trainingRes.data.data.result.map((t: any) => ({
            value: t._id,
            label: t.name
          }))
        );
      } catch (error) {
        console.error('Error fetching filter options:', error);
        toast({
          title: 'Error',
          description: 'Failed to load filter options.',
          variant: 'destructive'
        });
      }
    };
    fetchOptions();
  }, []);

  // Refetch employees when filters/pagination/searchTerm change
  useEffect(() => {
    fetchData();
  }, [
    currentPage,
    entriesPerPage,
    searchTerm,
    selectedDepartment,
    selectedDesignation,
    selectedTraining
  ]);

  const handleSearch = () => {
    setCurrentPage(1);
    setSearchTerm(searchInput);
  };

  const handleResetFilters = () => {
    setSearchInput('');
    setSearchTerm('');
    setSelectedDepartment(null);
    setSelectedDesignation(null);
    setSelectedTraining(null);
    setCurrentPage(1);
  };

  const handleStatusChange = async (id: string, status: boolean) => {
    try {
      const updatedStatus = status ? 'active' : 'block';
      await axiosInstance.patch(`/users/${id}`, { status: updatedStatus });
      toast({
        title: 'Success',
        description: 'Status updated successfully.',
        className: 'bg-theme text-white'
      });
      fetchData();
    } catch (error: any) {
      console.error('Error updating status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update status.',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-3 ">
      {/* Page Header */}

      {/* Search & Filter Section */}
      <div className="space-y-5 rounded-lg bg-white p-5 shadow-sm">
        <div className="flex flex-row items-center gap-4">
          <div className="flex items-center">
            <h2 className="flex items-center gap-2 text-2xl font-bold text-gray-900">
              <Users2 className="h-6 w-6" />
              All Employees
            </h2>{' '}
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <Input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search by name, email"
                className="h-10 text-sm"
              />
            </div>
            <div>
              <Select
                options={departments}
                value={selectedDepartment}
                onChange={setSelectedDepartment}
                placeholder="Department"
                isClearable
                className="text-sm"
                menuPortalTarget={document.body}
                styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
              />
            </div>
            <div>
              <Select
                options={designations}
                value={selectedDesignation}
                onChange={setSelectedDesignation}
                placeholder="Designation"
                isClearable
                className="text-sm"
                menuPortalTarget={document.body}
                styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
              />
            </div>
            {/* <div>
            <Select
              options={trainings}
              value={selectedTraining}
              onChange={setSelectedTraining}
              placeholder="Training"
              isClearable
              className="text-sm"
              menuPortalTarget={document.body}
              styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
            />
          </div> */}
            <div className="flex w-full flex-row items-center gap-3">
              <Button
                onClick={handleSearch}
                className="flex h-9 w-20 items-center gap-1 bg-theme text-white hover:bg-theme/90"
                size="sm"
              >
                Search
              </Button>
              <Button
                variant="outline"
                onClick={handleResetFilters}
                size="sm"
                className="flex h-9 items-center gap-1"
              >
                Reset Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Employee Table */}

        {initialLoading ? (
          <div className="flex justify-center py-8">
            <BlinkingDots size="large" color="bg-theme" />
          </div>
        ) : employees.length === 0 ? (
          <div className="flex justify-center py-8 text-gray-500">
            No employees found matching your criteria.
          </div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Designation</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {employees.map((employee) => (
                  <TableRow key={employee._id} className="cursor-pointer">
                    <TableCell onClick={() => navigate(`${employee._id}`)}>
                      {employee.title} {employee.firstName} {employee.initial}{' '}
                      {employee.lastName}
                    </TableCell>
                    <TableCell onClick={() => navigate(`${employee._id}`)}>
                      {employee.email}
                    </TableCell>
                    <TableCell onClick={() => navigate(`${employee._id}`)}>
                      {employee.mobilePhone || '–'}
                    </TableCell>
                    <TableCell onClick={() => navigate(`${employee._id}`)}>
                      {Array.isArray(employee.departmentId) &&
                      employee.departmentId.length > 0
                        ? employee.departmentId
                            .map((dep: any) => dep.departmentName)
                            .join(', ')
                        : '–'}
                    </TableCell>

                    <TableCell onClick={() => navigate(`${employee._id}`)}>
                      {Array.isArray(employee.designationId) &&
                      employee.designationId.length > 0
                        ? employee.designationId
                            .map((des: any) => des.title)
                            .join(', ')
                        : '–'}
                    </TableCell>

                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-2">
                        {/* Status Badge */}

                        {/* Toggle Switch with Custom Color Override */}
                        <Switch
                          checked={employee.status === 'active'}
                          onCheckedChange={(checked) =>
                            handleStatusChange(employee._id, checked)
                          }
                          className="data-[state=checked]:bg-theme data-[state=checked]:hover:bg-theme/90"
                        />
                        <Badge
                          variant={
                            employee.status === 'active'
                              ? 'default'
                              : 'secondary'
                          }
                          className={`
        min-w-[70px] justify-center shadow-none
        ${
          employee.status === 'active'
            ? 'bg-theme text-white hover:bg-theme/90'
            : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
        }
      `}
                        >
                          {employee.status === 'active' ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="bg-theme text-white hover:bg-theme/90"
                        onClick={() =>
                          navigate(`${employee._id}/employee-rate`, {
                            state: employee
                          })
                        }
                      >
                        Pay Rate
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="bg-theme text-white hover:bg-theme/90"
                        onClick={() => navigate(`${employee._id}`)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {employees.length > 50 && (
              <div className="mt-6">
                <DynamicPagination
                  pageSize={entriesPerPage}
                  setPageSize={setEntriesPerPage}
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={setCurrentPage}
                />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
